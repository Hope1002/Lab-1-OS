/*
 * Skeleton code for ps.c
 */
#include "kernel/param.h"
#include "kernel/types.h"
#include "user/uproc.h"
#include "user/user.h"

int
main(int argc, char **argv)
{
  struct uproc uproc[NPROC];
  int nprocs;
  
    static char *states[] = {
  	[UNUSED]    "unused",
  	[SLEEPING]  "sleep ",
  	[RUNNABLE]  "runble",
  	[RUNNING]   "run   ",
 	 [ZOMBIE]    "zombie"
      };
      char *state;
  /********************************
   * Add any additional variables or data structures you will need
   ********************************/
  nprocs = getprocs(uproc);
  
  if(nprocs<0){
  	exit(-1);
  }
  
  for(int i = 0; i<nprocs ;i++){
  	state = states[uproc[i].state];
  	printf("%d", uproc[i].pid);
  	printf("%s", state);
  	printf("%d", uproc[i].size);
  	printf("%d", uproc[i].ppid);	
  }
  /*********************************
   * Add your code here to output information returned by getprocs()
   * Hint: see procdump() code in kernel/console.c, except that here
   * you will be outputting the first nprocs elements of the uproc array
   * and all will have active states.
   *********************************/ 
  exit(0);
}
